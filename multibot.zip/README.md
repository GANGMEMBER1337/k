# Multipurpose Discord bot

Moderation, server setup tools and Last.fm/fun commands. Every command works both as a prefix command (default `;`) and as a slash command. Run `;help` for the full list.

## Commands

**Moderation**: `ban` `unban` `kick` `timeout` `untimeout` `warn` `warnings` `clearwarnings` `purge` `slowmode` `lock` `unlock` `modlog`

**Server setup** (need Manage Server):
- `welcome channel|message|test|off` and `leave channel|message|off`. Placeholders: `{user}` `{user.name}` `{server}` `{count}`
- `autorole @role` (empty to turn off)
- `reactionrole add <message> <emoji> <role>`, `remove`, `list`
- `starboard channel|threshold|off`
- `ticket panel|category|staffrole`
- `prefix [new]`

**Last.fm & fun**: `lastfm set <user>`, `np`, `lastfm topartists [period]`, `lastfm toptracks [period]`, `8ball`, `avatar`, `banner`, `userinfo`, `serverinfo`

## Files

All files live in one flat folder so they are easy to upload from a phone:
`main.py`, `db.py`, `cog_moderation.py`, `cog_setup.py`, `cog_fun.py`, `requirements.txt`, `Dockerfile`, `railway.toml`, `env.example`, `README.md`.

## 1. Create the bot in Discord

1. Open https://discord.com/developers/applications (use your phone browser's "Desktop site" option if the page looks broken) and tap **New Application**.
2. **Bot** tab > **Reset Token** and copy it. This is your `DISCORD_TOKEN`. Keep it private.
3. On the same tab, turn on **Server Members Intent** and **Message Content Intent**. The bot will not start without them.
4. **OAuth2 > URL Generator**: scopes `bot` and `applications.commands`. Permissions: Ban Members, Kick Members, Moderate Members, Manage Messages, Manage Roles, Manage Channels, View Channels, Send Messages, Embed Links, Add Reactions, Read Message History (or Administrator to keep it simple).
5. Open the generated URL to add the bot to your server.
6. In Server Settings > Roles, drag the bot's role **above** the roles it should moderate or hand out.

## 2. Put the code on GitHub (from a phone)

1. Download `multibot.zip` and unzip it with your Files app (iPhone: tap the zip. Android: Files > tap the zip > Extract). You should end up with a folder of 10 files.
2. In your phone browser, sign in at github.com and create a repo: **+ > New repository**, name it, choose **Private**, and create it.
3. On the empty repo page, tap the **uploading an existing file** link.
4. Tap **choose your files** and select **all 10 files** from the unzipped folder. Don't upload the zip itself, GitHub won't unpack it.
5. Scroll down and tap **Commit changes**.

The repo should show the files directly on its main page (no folder in between). Do not upload a `.env` file or your token.

## 3. Deploy on Railway (from a phone)

1. Open https://railway.com in your browser and sign in with GitHub.
2. **New Project > Deploy from GitHub repo**, pick your repo (allow Railway to access it if asked). It finds the `Dockerfile` and `railway.toml` on its own.
3. Open the service > **Variables** and add:
   - `DISCORD_TOKEN` (required)
   - `LASTFM_API_KEY` (optional, for the Last.fm commands)
   - `DEFAULT_PREFIX` (optional, defaults to `;`)
4. **Add a volume** so your data survives redeploys: in the project, add a **Volume**, attach it to the bot service and set the mount path to `/data`. The bot detects it automatically. Without a volume, warnings, welcome settings, reaction roles and the starboard reset on every deploy.
5. Open **Deployments** and check the logs. A good start shows `Logged in as <your bot>`.
6. It is a background worker, so you don't need a public domain.

To update the bot later, edit a file on GitHub (open it and tap the pencil icon) and commit. Railway redeploys automatically.

### Troubleshooting

- `DISCORD_TOKEN is not set`: add it under the service's Variables.
- `PrivilegedIntentsRequired`: enable Server Members Intent and Message Content Intent in the Developer Portal (step 1.3).
- `ModuleNotFoundError` for a `cog_` file or `db`: a file was missed in the upload. Make sure all 10 files are in the repo's main page.
- Slash commands don't show up right away: global commands can take a while. Set `GUILD_ID` to your server's ID to get them instantly while testing.
- "I can't do that" messages: move the bot's role higher in Server Settings > Roles.

## Run on a computer (optional)

```
pip install -r requirements.txt
cp env.example .env   # fill in the token
python main.py
```

## Not included

Music playback, antinuke/antiraid, leveling and economy. Music in particular is awkward to host because YouTube blocks most cloud server IPs.
